import PyPDF2
import difflib
import os

'''
reading pdf file and creating the new file


fori = open(r'C:\Users\jouve\Documents\s.pdf', 'rb')
fdup = open(r'C:\Users\jouve\Downloads\ff.pdf','rb')
d = PyPDF2.PdfFileReader(fori)
d2 =PyPDF2.PdfFileReader(fdup)
pageObj = d.getPage(0)
pageObj2 = d2.getPage(0)
ftext = pageObj.extractText()
f2text  =pageObj2.extractText()
f1 = open('fmain', 'w')
f2 = open('fduppi','w')
for i in str(ftext):
    f1.write(i)
print('completed 1', len(ftext))
for j in str(f2text):
    f2.write(j)
print("completed 2",len(f2text))

'''


'''
now comparing
'''


'''fo = open(r'C:\Users\jouve\Documents\s.pdf', 'rb')
fdup = open(r'C:\Users\jouve\Downloads\ff.pdf','rb')
d = PyPDF2.PdfFileReader(fo)
d2 = PyPDF2.PdfFileReader(fdup)
pageObj = d.getPage(0)
pageObj2 = d2.getPage(0)
ftext = pageObj.extractText()
f2text  =pageObj2.extractText()
f1 = open('fmain', 'w')
f2 = open('fduppi','w')
for i in str(ftext):
    f1.write(i)
print('completed 1', len(ftext))
for j in str(f2text):
    f2.write(j)
print("completed 2", len(f2text))
'''