from django.shortcuts import render
from django.views import generic
from .models import Item_category, Items, Item_subcategory
# Create your views here.

# class Booklist(generic.ListView):
#     model1 = Items
#     context_object_name = 'my_items_list'
#     template_name = 'book/templates/booklist.html'
def Booklist(request):
    all_items = Items.objects.all()
    context = {'all_items':all_items}
    return render(request, 'book/booklist.html', context)
# def insidelist(request,it_name):
#     all_insidelist = Item_category.objects.all()
#     context  ={"all_insidelist":all_insidelist}
#     return render(request, 'book/insidelist.html', context)
def food(request):
    all_food = Item_category.objects.filter(item_categ_id=1)
    context ={'all_food':all_food}
    return render(request, 'book/food.html', context)
def bevarages(request):
    all_bevarages = Item_category.objects.filter(item_categ_id=2)
    context ={'all_food':all_bevarages}
    return render(request, 'book/bevarages.html', context)
def dessert(request):
    all_dessert = Item_category.objects.filter(item_categ_id=3)
    context = {'all_food':all_dessert}
    return render(request, 'book/dessert.html', context)
def veg(request):
    all_veg = Item_subcategory.objects.filter(item_subcateg=2)
    context = {'all_veg': all_veg}

    return render(request, 'book/veg.html', context)
def nonveg(request):
    all_nonveg = Item_subcategory.objects.filter(item_subcateg=3)
    context = {'all_nonveg': all_nonveg}
    return render(request, 'book/nonveg.html', context)
