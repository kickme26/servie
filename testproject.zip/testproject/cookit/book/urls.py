from django.urls import path
from . import views

app_name = 'book'

urlpatterns = [

    path('', views.Booklist, name='book'),
    path('Food/', views.food, name='foodlist'),
    path('Bevarages/', views.bevarages, name='bevarageslist'),
    path('Dessert/', views.dessert, name='dessertlist'),
    path('Food/Pure-veg', views.veg, name='veglist'),
    path('Food/Non-veg', views.nonveg, name='nonveglist'),
    # path('book/<int:pk>', views.BookDetailView.as_view(), name='book-detail'),

]
