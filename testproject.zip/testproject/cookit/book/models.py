from django.db import models


# Create your models here.
class Items(models.Model):
    item_name = models.CharField(max_length=30)

    def __str__(self):
        return self.item_name


class Item_category(models.Model):
    item_categ = models.ForeignKey('Items', on_delete=models.CASCADE)
    categ_title = models.CharField(max_length=20)

    def __str__(self):
        return self.categ_title


class Item_subcategory(models.Model):
    item_subcateg = models.ForeignKey('Item_category', on_delete=models.CASCADE)
    subcategory_title = models.CharField(max_length=20)

    def __str__(self):
        return self.subcategory_title
